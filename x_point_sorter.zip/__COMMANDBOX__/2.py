#!/usr/bin/env python3

"""
Created Feb 23 2023

@author: rondinil

Script to plot E_parallel and E_perpendicular of particles then color-code them
according to whether they are good curvature, bad curvature or passing

The only thing that needs to be changed (apart from the labels on the plot itself) 
is the number of the equilibrium in line 98
"""

import numpy as np
import scipy as scipy
import matplotlib.pyplot as plt
from scipy import interpolate

def readin(eq): 
    '''
    function to read in passing/bounce points, energy discribution
    
    Inputs: 
    eq -  filename
        name of equilibrium
    
    Returns:
    good_curv_E, bad_curv_E, passing_E - list, list, list
        E distributions of good curvature, bad curvature and passing points in (Epar, Eperp) form
    eq - str
        name of equilibrium (for the plot title)
    '''
    eq = str(eq)
    good_curv_E = OMFIT['scans'][eq]['good_curv_E']
    bad_curv_E = OMFIT['scans'][eq]['bad_curv_E']
    passing_E = OMFIT['scans'][eq]['passing_E']
    
    

    return good_curv_E, bad_curv_E, passing_E, eq

def plot(good_curv_E, bad_curv_E, passing_E, eq):
    '''
    function to plot Epar, Eperp and then good curvature, bad curvature and passing points as a scatterplot

    Takes:
    good_curv_E, bad_curv_E, passing_E - list, list, list
        E distributions of good curvature, bad curvature and passing points in (Epar, Eperp) form
    eq - str 
        name of equilibrium (for plot title)

    Returns: 0 (int)

    '''
    # need to split into Epar and Eperp
    print(good_curv_E)
    print(passing_E)
    print(len(good_curv_E))
    print(len(bad_curv_E))
    print(len(passing_E))

    Epar_g = [item[0] for item in good_curv_E]
    Eperp_g = [item[1] for item in good_curv_E]

    Epar_b = [item[0] for item in bad_curv_E]
    Eperp_b = [item[1] for item in bad_curv_E]

    Epar_p = [item[0] for item in passing_E]
    Eperp_p = [item[1] for item in passing_E]

    fig = plt.figure(figsize = (8,8))
    ax = subplot(111)
    fontsize = 24
    labelsize = fontsize-4
    ax.tick_params(axis='both', which='major', labelsize=labelsize)
    plt.scatter(Epar_g, Eperp_g, color = 'midnightblue', marker = 'o', s = 30, label = "good curvature bounces")
    plt.scatter(Epar_b, Eperp_b, color = 'darkorange', marker = 'v', s = 30, label = "bad curvature bounces")
    plt.scatter(Epar_p, Eperp_p, color = 'palevioletred', marker = 'D', s = 30, label = "passing orbits")
    plt.legend(loc = 'upper right', fontsize=15.5)
    ax.set_xlim(-25, 800)
    ax.set_ylim(25, 800)
    #plt.title("Energy Distr, Good Curvature, Bad Curvature and Passing Points for " + eq + " Delta = -0.5, 3/4")
    #ax.text(0.6,0.2,'Eq: ' + eq, ha='left', va='center', transform=ax.transAxes, fontsize=fontsize, color='black')
    #ax.text(0.65,0.2,r'$\delta$ = -0.5', ha='left', va='center', transform=ax.transAxes, fontsize=fontsize)
    #ax.text(0.65,0.15,r'$\kappa$ = 1.0', ha='left', va='center', transform=ax.transAxes, fontsize=fontsize)
    #ax.text(0.65,0.1,'a = 0.6', ha='left', va='center', transform=ax.transAxes, fontsize=fontsize)
    #ax.text(0.65,0.1,r'$\rho$/a = 3/4', ha='left', va='center', transform=ax.transAxes, fontsize=fontsize)
    plt.xlabel("E parallel (eV)", fontsize = fontsize)
    plt.ylabel("E perpendicular (eV)", fontsize = fontsize)
    #plt.axis("equal")
    plt.tight_layout()
    plt.show()

    return 0 

#main
good_curv_E, bad_curv_E, passing_E, eq = readin(412003) # this number is the only thing you need to change to run the script!
plot(good_curv_E, bad_curv_E, passing_E, eq)