eq = 411008
eq_name = 'g411008.01000'
flux = OMFIT['scans'][str(eq)][eq_name]['fluxSurfaces']['flux'] 
r=OMFIT['scans'][str(eq)][eq_name]['fluxSurfaces']['flux'][110]['R']
z=OMFIT['scans'][str(eq)][eq_name]['fluxSurfaces']['flux'][110]['Z']
print(max(r))