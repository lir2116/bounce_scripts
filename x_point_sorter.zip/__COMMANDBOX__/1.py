#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: rondinil

File to sort output of parser.py into passing / good curvature / bad curvature 
Records the energies of good, bad and passing particles under good_curv_E, bad_curv_E and passing_E
These become the inputs for the square plot file

The order of this file is: 
imports 
defining inputs
functions 
main
plotting

BEFORE RUNNING: 
- create an OMFIT tree lableled with the number of the equilibrium and change the "eq" variable to this number
- add the geqdsk file of the equilibrium to the OMFIT tree and change the "eq_name" variable to this string
- check filename, passing_file, E_file under "main" to make sure the energies are correct and edit if necessary 

"""

import numpy as np
import scipy as scipy
import matplotlib.pyplot as plt
from scipy import interpolate
from scipy.interpolate import CubicSpline
import ast

# change these inputs to your OMFIT tree name and geqdsk name
eq = 412003
eq_name = 'g412003.01000'

eq_filename = eq_name
eq_dirin = './input/'
eq_data = OMFIT['scans'][str(eq)][eq_name]


def read(dirin, filename, Efile, eq): # reads in and formats the data from the bounce point file
    '''
    Inputs: 
    ---------
    dirin: directory path
    directory that the file is in 

    filemame: filename
    name of the txt file containing bounce points

    Efile: filename
    name of file containing energies of bounces

    eq: str
    equilibrium name, determines where to save the energies to the tree

    Returns: 
    ---------
    coords: list
    list of (R, Z) pairs of bounce points

    coords_r: list
    list of R coordinates of bounce points

    coords_z: list
    list of Z coordinates of bounce points

    Edistr: list
    list of eneries of bounce points in form [[Epar, Eperp], [Epar, Eperp]...]

    '''
    f = open(dirin + filename, 'r')
    coords = []
    coords_r = []
    coords_z = []
    for line in f: 
        line_replace = line.replace("\n", "")
        line_stripped = line_replace.strip("[] ")
        split_line = line_stripped.split()

        for entry in split_line: 
            if entry == '': 
                del split_line[split_line.index(entry)]
        coords_r.append(float(split_line[0]))
        coords_z.append(float(split_line[1]))
        coords.append(tuple([float(split_line[0]), float(split_line[1])]))

    # save these coordinates to a tree entry 
    OMFIT['scans']['coords'] = coords
    OMFIT['scans']['coords_r'] = coords_r
    OMFIT['scans']['coords_z'] = coords_z

    g = open(dirin + Efile, 'r')
    lines = g.readlines()
    line = lines[0]
    line = ast.literal_eval(line)
    OMFIT['scans'][str(eq)]['Edistr'] = line
    Edistr = line

    return coords, coords_r, coords_z, Edistr

def passing(dirin, filename, Efile, eq): # pulls number of passing particles from 'info' file and their energies from 'Edistr' file
    '''
    Inputs: 
    -------
    dirin: directory path
    directory containing 'info' txt file
  
    filename: file name
    filename of 'info' txt file

    Efile: file name
    filename of Edistr txt file

    eq: str
    name of equilibrium, this is used to determine where to save info in tree

    Returns: 
    -------
    passing: int
    number of passing particles

    Epass: list
    energies of passing particles in form [[Epar, Eperp], [Epar, Eperp], ...]
    '''
    # number of passing particles is the 2nd entry in the 2nd line of 'info'
    # lines end with * but do not start with *
    f = open(dirin + filename, 'r')
    lines = f.readlines()
    OMFIT['scans']['passing'] = int(lines[1][2])
    passing = int(lines[1][2])

    g = open(dirin + Efile, 'r')
    lines = g.readlines()
    line = lines[1]
    line = ast.literal_eval(line)
    OMFIT['scans'][str(eq)]['passing_E'] = line
    passing_E = line

    return passing, passing_E

def curv(bounces, no, eq): # sorts into good and bad curvature bounces
        '''
        Inputs: 
            bounces - list
            list of bounce points
            no - int
            branch of the tree you want to take fmax, fmin from 
            eq - str
            name of equilibrium, used to access Edistr
            
        Returns: 
            good_curv, bad_curv - list, list
            lists of good and bad curvature bounce points
        '''
        good_curv = []
        bad_curv = []

        good_curv_E = []
        bad_curv_E = []
        index = 0
        Edistr = OMFIT['scans'][str(eq)]['Edistr']
        
        fmax = OMFIT['var'][no]['fmax']
        fmin = OMFIT['var'][no]['fmin']

        for item in bounces: 
            if item[1] > 0: 
                if (fmax(item[1])) > item[0]: # z>0, want r to the left of the line
                    good_curv.append(item)
                    good_curv_E.append(Edistr[index])
                    index += 1
                else: 
                    bad_curv.append(item)
                    bad_curv_E.append(Edistr[index])
                    index += 1
            else: 
                if (fmin(item[1])) > item[0]: # z<0 want r to the left of the line
                    good_curv.append(item)
                    good_curv_E.append(Edistr[index])
                    index += 1
                else: 
                    bad_curv.append(item) 
                    bad_curv_E.append(Edistr[index])
                    index += 1


        OMFIT['scans'][str(eq)]['good_curv'] = good_curv
        OMFIT['scans'][str(eq)]['bad_curv'] = bad_curv
        OMFIT['scans'][str(eq)]['bad_curv'] = bad_curv
        OMFIT['scans'][str(eq)]['good_curv_E'] = good_curv_E
        OMFIT['scans'][str(eq)]['bad_curv_E'] = bad_curv_E
        return good_curv, bad_curv, good_curv_E, bad_curv_E
    

def surface_points(scan, res, n, _min, _max, no, eq, eq_name): # finds (r, z_max) and (r, z_min) for each flux surface

    '''

    Inputs:
    ----------
    scan : file path
        folder containing eqdsk files you want to analyze
    res : int
        grid resolution of eqdsks in scan
    _min : float
        minimum triangularity 
    _max : float
        maximum triangularity
    no: int
        number to start labelling at

    Returns:
    -------
    max_list: list
        list of [r,z] pairs corresponding to the maximum z point of each flux surface in the last scan
    min_list: list
        list of [r,z] pairs corresponding to the maximum z point of each flux surface in the last scan
    '''

    #iterates through scan
    #print(scan)
    for item in scan:
        eqdsk = scan[item]
        T=1.2e3
        surfaces=list(range(0,res-1))  # need -1 so that we don't try to go past the number of surfaces
        #iterates through flux surfaces
        max_list = []
        min_list = []
        for surface in surfaces:
            # computes r and z coordinates for each flux surface
            # and the next surface
            r=OMFIT['scans'][str(eq)][eq_name]['fluxSurfaces']['flux'][surface]['R']
            z=OMFIT['scans'][str(eq)][eq_name]['fluxSurfaces']['flux'][surface]['Z']

            # find the min and max z values of each surface and the corresponding r values
            max_z = np.max(z)
            min_z = np.min(z)
            max_r_ind = np.argmax(z)
            min_r_ind = np.argmin(z)
            max_r = r[max_r_ind]
            min_r = r[min_r_ind]
            
            max_list.append([max_r, max_z])
            min_list.append([min_r, min_z])

        OMFIT['var'][no] = OMFITtree()
        OMFIT['var'][no]['max_list'] = max_list
        OMFIT['var'][no]['min_list'] = min_list
        no += 1
    return max_list, min_list

def curv_line(max_list, min_list, no): 
# function to make two lines - one connecting all the max points of the flux surfaces and one connecting all the min points
# "no" corresponds to the place in the tree they will be saved to 
    r_maxs = [entry[0] for entry in max_list]
    z_maxs = [entry[1] for entry in max_list]

    r_mins = [entry[0] for entry in min_list]
    z_mins = [entry[1] for entry in min_list]

    fmax = interpolate.interp1d(z_maxs, r_maxs, bounds_error = None, fill_value = 'extrapolate')
    fmin = interpolate.interp1d(z_mins, r_mins, bounds_error = None, fill_value = 'extrapolate')

    OMFIT['var'][no]['fmax'] = fmax
    OMFIT['var'][no]['fmin'] = fmin
    
    return fmax, fmin


#########################################################################################################
#main --defines arguments and runs script


scan = OMFIT['scans'][str(eq)]
flux = OMFIT['scans'][str(eq)][eq_name]['fluxSurfaces']['flux'] 
res= len(flux.keys())
n=2500
_min=-0.18
_max=0.26

dirin = "../../../../../home/rondinil/Bounce/Bounce/"
filename = f"bounces_{eq_name}_300_750_150_78.txt"
passing_file = f"info_{eq_name}_300_750_150_78.txt"
Efile = f"Edistr_{eq_name}_300_750_150_78.txt"

read(dirin, filename, Efile, eq) # reads in file
passing, passing_E = passing(dirin, passing_file, Efile, eq) # makes list of passing particle energies

surface_points(scan, res, n, _min, _max, 0, eq, eq_name) # finds (r, z_min/max) points for each flux surface

# save flux surface max/min points to tree
max_list = OMFIT['var'][1]['max_list']
min_list = OMFIT['var'][1]['min_list']
fmax, fmin = curv_line(max_list, min_list, 1) # fits a line to the (r, z_min/max) points

# grab bounce points from tree
bounce_list = OMFIT['scans']['coords']
good_curv, bad_curv, good_curv_E, bad_curv_E = curv(bounce_list, 1, eq) # sorts bouncing particles into good/bad curvature

# save sorted bounce points and energies to tree
OMFIT['scans']['good_curv'] = good_curv
OMFIT['scans']['bad_curv'] = bad_curv    
OMFIT['scans']['good_curv_E'] = good_curv_E
OMFIT['scans']['bad_curv_E'] = bad_curv_E 

# calculate the good curvature trapped fraction and save to tree
OMFIT['scans'][str(eq)]['gc_frac'] = (len(good_curv) / (passing + len(bad_curv) + len(good_curv)))  


#####################################################################################################
# everything below here is just for plotting the eq and bounce points!

eq_center = (eq_data['RMAXIS'], eq_data['ZMAXIS'])
last_cfs_r = eq_data['RBBBS']
last_cfs_z = eq_data['ZBBBS']

max_z_cfs = np.max(eq_data['ZBBBS'])
min_z_cfs = np.min(eq_data['ZBBBS'])
max_r_ind = np.where(eq_data['ZBBBS'] == max_z_cfs)
min_r_ind = np.where(eq_data['ZBBBS'] == min_z_cfs)

max_r_cfs = eq_data['RBBBS'][max_r_ind][0]
min_r_cfs = eq_data['RBBBS'][min_r_ind][0]

# range to plot our lines over (change test_range_max/min depending on elongation of equilibrium)
r_coords_u = np.arange(np.min([eq_center[0], max_r_cfs]), np.max([eq_center[0], max_r_cfs]), 0.01)
r_coords_l = np.arange(np.min([eq_center[0], min_r_cfs]), np.max([eq_center[0], min_r_cfs]), 0.01)
test_range_max = np.arange(0, 0.85, 0.05)
test_range_min = np.arange(-0.84, -0.01, 0.05)


# make our lines
f_maxs = list(np.squeeze(np.array([fmax(item) for item in test_range_max])))
f_mins = list(np.squeeze(np.array([fmin(item) for item in test_range_min])))

r_maxs = [entry[0] for entry in max_list]
z_maxs = [entry[1] for entry in max_list]
r_mins = [entry[0] for entry in min_list]
z_mins = [entry[1] for entry in min_list]

# grab our bounce points        
rg = [item[0] for item in good_curv]
zg = [item[1] for item in good_curv]
rb = [item[0] for item in bad_curv]
zb = [item[1] for item in bad_curv]

fig = plt.figure(figsize = (6,8))
ax = subplot(111)
fontsize = 22
labelsize = fontsize-2
ax.tick_params(axis='both', which='major', labelsize=labelsize)

ax.set_xlabel(r'$\it{R}$ (m)', fontsize=fontsize)

plt.scatter(rg, zg, c = 'midnightblue', marker = 'D', edgecolor = 'None', s=80, label = 'good curvature bounces')
plt.scatter(rb, zb, c = 'darkorange', marker = 'o', edgecolor = 'None', s=80, label = 'bad curvature bounces')
#plt.legend(loc = 'best', fontsize = 17)
#plt.axis('equal') # uncomment for equal axis scales


plt.plot(f_maxs, test_range_max, c= 'k', linewidth = 2, linestyle = (0, (10, 10)))
plt.plot(f_mins, test_range_min, c = 'k', linewidth = 2, linestyle = (0, (10, 10)))

#test_range_max = list(test_range_max)
#test_range_min = list(test_range_min)


#f_maxs = f_maxs.reverse()
#f_mins = f_mins.reverse()
#test_range_max = test_range_max.reverse()
#test_range_min = test_range_min.reverse()

#print(test_range_max)
#print(f_maxs)

#i_maxs = CubicSpline(f_maxs, test_range_max)
#i_mins = CubicSpline(f_mins, test_range_min)

#plt.plot(f_maxs, i_maxs(f_maxs), c= 'k', linestyle = (0, (10, 10)))
#plt.plot(f_mins, i_mins(f_mins), c = 'k', linestyle = (0, (10, 10)))

plt.plot(eq_data['RBBBS'], eq_data['ZBBBS'], label=eq_filename, lw = 3, color = 'k')
#plt.scatter(eq_data['RMAXIS'], eq_data['ZMAXIS'], marker='x', s=10)

plt.axis('equal')
ax.set_xlabel(r'$\it{R}$ (m)', fontsize=fontsize)
ax.set_ylabel(r'$\it{Z}$ (m)', fontsize=fontsize)
ax.set_xlim(0.85, 2.15)
ax.set_ylim(-0.8, 0.9)
ax.tick_params(axis = 'both', which = 'major', labelsize = labelsize)
ax.contour(eq_data['AuxQuantities']['R'], eq_data['AuxQuantities']['Z'], eq_data['AuxQuantities']['PSIRZ_NORM'], levels=np.arange(0,1,0.2), linestyles='--', colors='k')
#ax.annotate('', xy=(1.74,-0.56), xytext=(1.3, -0.86), arrowprops=dict(arrowstyle='simple,head_length=1.8,head_width=1',connectionstyle='arc3, rad=0.1', fc='k'))
#ax.text(0.73, -0.86, "line between", ha='left', va='center', fontsize=17, color='black')
#ax.text(0.73, -0.96, "good and bad", ha='left', va='center', fontsize=17, color='black')
#ax.text(0.73, -1.06, "curvature regions", ha='left', va='center', fontsize=17, color='black')
ax.text(0.9, 0.85, r'$\delta$ = -0.5', ha='left', va='center', fontsize = 23, color = 'black')
ax.text(0.9, 0.75, r'$\kappa$ = 1.0', ha='left', va='center', fontsize = 23, color = 'black')
ax.text(0.9, 0.65, 'a = 0.6', ha='left', va='center', fontsize = 23, color = 'black')
#ax.text(0.73, 0.81, r'$\rho$/a = 3/4', ha='left', va='center', fontsize = 25, color = 'black')
plt.tight_layout()