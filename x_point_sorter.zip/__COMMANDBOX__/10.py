#!/usr/bin/env python3

"""
Created Jan 23 2024

@author: rondinil

Script to plot E_parallel and E_perpendicular of particles then color-code them
according to whether they are lost to the limiter, x points, or bouncing/passing

The only thing that needs to be changed (apart from the labels on the plot itself) 
is the number of the equilibrium in line 98
"""

import numpy as np
import scipy as scipy
import matplotlib.pyplot as plt
from scipy import interpolate

def readin(eq): 
    '''
    function to read in passing/bounce points, energy discribution
    
    Inputs: 
    eq -  filename
        name of equilibrium
    
    Returns:
    los_x_E, los_l_E, passing_E - list, list, list
        E distributions of lost to x points, lost to limiter and and passing points in (Epar, Eperp) form
    eq - str
        name of equilibrium (for the plot title)
    '''
    eq = str(eq)
    limiter_E = OMFIT['scans'][eq]['limiter_E']
    xpoint_E = OMFIT['scans'][eq]['xpoint_E']
    bp_E = OMFIT['scans'][eq]['bp_E']
    
    

    return limiter_E, xpoint_E, bp_E, eq

def plot(limiter_E, xpoint_E, bp_E, eq):
    '''
    function to plot Epar, Eperp and then limiter_E, xpoint_E and bouncing/passing points as a scatterplot

    Takes:
    limiter_E, xpoint_E, bp_E - list, list, list
        E distributions of lost to limiter, lost to x points, and bouncing/passing points in (Epar, Eperp) form
    eq - str 
        name of equilibrium (for plot title)

    Returns: 0 (int)

    '''
    # need to split into Epar and Eperp
    print(limiter_E)
    print(xpoint_E)
    print(bp_E)
    print(len(limiter_E))
    print(len(xpoint_E))
    print(len(bp_E))

    Epar_l = [item[0] for item in limiter_E]
    Eperp_l = [item[1] for item in limiter_E]

    Epar_x = [item[0] for item in xpoint_E]
    Eperp_x = [item[1] for item in xpoint_E]

    Epar_bp = [item[0] for item in bp_E]
    Eperp_bp = [item[1] for item in bp_E]

    fig = plt.figure(figsize = (8,8))
    ax = subplot(111)
    fontsize = 24
    labelsize = fontsize-4
    ax.tick_params(axis='both', which='major', labelsize=labelsize)
    plt.scatter(Epar_l, Eperp_l, color = 'midnightblue', marker = 'o', s = 30, label = "lost to limiter")
    plt.scatter(Epar_x, Eperp_x, color = 'darkorange', marker = 'v', s = 30, label = "lost to x point")
    plt.scatter(Epar_bp, Eperp_bp, color = 'palevioletred', marker = 'D', s = 30, label = "bouncing/passing")
    plt.legend(loc = 'upper right', fontsize=15.5)
    ax.set_xlim(-25, 800)
    ax.set_ylim(25, 800)
    #plt.title("Energy Distr, Good Curvature, Bad Curvature and Passing Points for " + eq + " Delta = -0.5, 3/4")
    #ax.text(0.6,0.2,'Eq: ' + eq, ha='left', va='center', transform=ax.transAxes, fontsize=fontsize, color='black')
    #ax.text(0.65,0.2,r'$\delta$ = -0.5', ha='left', va='center', transform=ax.transAxes, fontsize=fontsize)
    #ax.text(0.65,0.15,r'$\kappa$ = 1.0', ha='left', va='center', transform=ax.transAxes, fontsize=fontsize)
    #ax.text(0.65,0.1,'a = 0.6', ha='left', va='center', transform=ax.transAxes, fontsize=fontsize)
    #ax.text(0.65,0.1,r'$\rho$/a = 3/4', ha='left', va='center', transform=ax.transAxes, fontsize=fontsize)
    plt.xlabel("E parallel (eV)", fontsize = fontsize)
    plt.ylabel("E perpendicular (eV)", fontsize = fontsize)
    #plt.axis("equal")
    plt.tight_layout()
    plt.show()

    return 0 

#main
limiter_E, xpoint_E, bp_E, eq = readin(412003) # this number is the only thing you need to change to run the script!
plot(limiter_E, xpoint_E, bp_E, eq)