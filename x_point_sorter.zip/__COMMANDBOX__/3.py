#!/usr/bin/env python3
# LIR file to plot gc trapped fractions for different equilibria

import numpy as np
import matplotlib.pyplot as plt

f0 = OMFIT['scans']['411000']['gc_frac']
f1 = OMFIT['scans']['411001']['gc_frac']
f2 = OMFIT['scans']['411002']['gc_frac']
f3 = OMFIT['scans']['411003']['gc_frac']
f4 = OMFIT['scans']['411004']['gc_frac']

frac_list = [f0, f1, f2, f3, f4]
deltas = [-0.6, -0.5, -0.4, -0.3, -0.2]
#label_list = ['411000', '411001', '411002', '411003', '411004']

fig = plt.figure(figsize = (6,8))
ax = subplot(111)
fontsize = 24
labelsize = fontsize-4
ax.tick_params(axis='both', which='major', labelsize=labelsize)
plt.scatter(deltas, frac_list)