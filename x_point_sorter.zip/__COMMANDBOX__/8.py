frac = open('/home/rondinil/Bounce/Bounce/frac_y.txt')
for i in [0, 1, 2, 3]:
     frac = open('/home/rondinil/Bounce/Bounce/frac_y.txt')
     for line in frac: 
         print(i, line)