"""
================================================
Defines a function (reqdgeq) that will read in a
gEQDSK file and return a data structure for
later plotting routines.

Written by: Oak Nelson 11/05/2021
================================================
"""

import os
import math
import numpy as np
from scipy import integrate


def readgeq(filename):
    cwd = os.getcwd() ## returns current working directory
    os.chdir(os.path.dirname(__file__)) ## change current working directory to specified path
    ## __file__ is a special variable containing the path to the module currently being imported
    ## here, the os.chdir command takes us to the directory containing the most recent import

    # -------------------------- Useful Functions ---------------------------- #

    def splitter(inv, step=16):
        value = []
        for k in range(len(inv) // step):
            value.append(inv[step * k : step * (k + 1)])
        return value

    def merge(inv):
        if not len(inv):
            return ''
        if len(inv[0]) > 80:
            # SOLPS gEQDSK files add spaces between numbers
            # and positive numbers are preceeded by a +
            return (''.join(inv)).replace(' ', '')
        else:
            return ''.join(inv)

    def naneval(val):
        if 'nan' not in val.lower():
            return eval(val)
        else:
            print("  ---> WARNING!!! NAN ENCOUNTERED!!!")
            return np.NaN

    # ------------------------- Start Read of File --------------------------- #

    data = {}

    # clean lines from the carriage returns
    ## a carriage return is denoted \r and takes the cursor back to the start of the line
    with open(filename, 'r') as f:
        EQDSK = f.read().splitlines() ## splits a string into a list, splitting done at line breaks

    # first line is description and sizes
    data['CASE'] = np.array(splitter(EQDSK[0][0:48], 8))
    try:
        tmp = list([_f for _f in EQDSK[0][48:].split(' ') if _f])
        [IDUM, data['NW'], data['NH']] = list(map(int, tmp[:3]))
    except ValueError:  # Can happen if no space between numbers, such as 10231023
        IDUM = int(EQDSK[0][48:52])
        data['NW'] = int(EQDSK[0][52:56])
        data['NH'] = int(EQDSK[0][56:60])
        tmp = []
        #printd('IDUM, NW, NH', IDUM, data['NW'], data['NH'], topic='geqdsk.load')
    if len(tmp) > 3:
        data['EXTRA_HEADER'] = EQDSK[0][49 + len(re.findall('%d +%d +%d ' % (IDUM, data['NW'], data['NH']), EQDSK[0][49:])[0]) + 2 :]
    offset = 1

    # now, the next 20 numbers (5 per row)

    # fmt: off
    [data['RDIM'], data['ZDIM'], data['RCENTR'], data['RLEFT'], data['ZMID'],
     data['RMAXIS'], data['ZMAXIS'], data['SIMAG'], data['SIBRY'], data['BCENTR'],
     data['CURRENT'], data['SIMAG'], XDUM, data['RMAXIS'], XDUM,
     data['ZMAXIS'], XDUM, data['SIBRY'], XDUM, XDUM] = list(map(naneval, splitter(merge(EQDSK[offset:offset + 4]))))
    # fmt: on
    offset = offset + 4

    # now read NW elements
    nlNW = int(np.ceil(data['NW'] / 5.0))
    data['FPOL'] = np.array(list(map(float, splitter(merge(EQDSK[offset : offset + nlNW])))))
    offset = offset + nlNW
    data['PRES'] = np.array(list(map(float, splitter(merge(EQDSK[offset : offset + nlNW])))))
    offset = offset + nlNW
    data['FFPRIM'] = np.array(list(map(float, splitter(merge(EQDSK[offset : offset + nlNW])))))
    offset = offset + nlNW
    data['PPRIME'] = np.array(list(map(float, splitter(merge(EQDSK[offset : offset + nlNW])))))
    offset = offset + nlNW
    try:
        # official gEQDSK file format saves PSIRZ as a single flat array of size rowsXcols
        nlNWNH = int(np.ceil(data['NW'] * data['NH'] / 5.0))
        data['PSIRZ'] = np.reshape(
            np.fromiter(splitter(merge(EQDSK[offset : offset + nlNWNH])), dtype=np.float64)[: data['NH'] * data['NW']],
            (data['NH'], data['NW']),
        )
        offset = offset + nlNWNH
    except ValueError:
        # sometimes gEQDSK files save row by row of the PSIRZ grid (eg. FIESTA code)
        nlNWNH = data['NH'] * nlNW
        data['PSIRZ'] = np.reshape(
            np.fromiter(splitter(merge(EQDSK[offset : offset + nlNWNH])), dtype=np.float64)[: data['NH'] * data['NW']],
            (data['NH'], data['NW']),
        )
        offset = offset + nlNWNH
    data['QPSI'] = np.array(list(map(float, splitter(merge(EQDSK[offset : offset + nlNW])))))
    offset = offset + nlNW

    # now vacuum vessel and limiters
    data['NBBBS'], data['LIMITR'] = list(map(int, [_f for _f in EQDSK[offset : offset + 1][0].split(' ') if _f][:2]))
    offset = offset + 1

    nlNBBBS = int(np.ceil(data['NBBBS'] * 2 / 5.0))
    data['RBBBS'] = np.array(list(map(float, splitter(merge(EQDSK[offset : offset + nlNBBBS]))))[0::2])[: data['NBBBS']]
    data['ZBBBS'] = np.array(list(map(float, splitter(merge(EQDSK[offset : offset + nlNBBBS]))))[1::2])[: data['NBBBS']]
    offset = offset + max(nlNBBBS, 1)

    try:
        # this try/except is to handle some gEQDSK files written by older versions of ONETWO
        nlLIMITR = int(np.ceil(data['LIMITR'] * 2 / 5.0))
        data['RLIM'] = np.array(list(map(float, splitter(merge(EQDSK[offset : offset + nlLIMITR]))))[0::2])[: data['LIMITR']]
        data['ZLIM'] = np.array(list(map(float, splitter(merge(EQDSK[offset : offset + nlLIMITR]))))[1::2])[: data['LIMITR']]
        offset = offset + nlLIMITR
    except ValueError:
        # if it fails make the limiter as a rectangle around the plasma boundary that does not exceed the computational domain
        data['LIMITR'] = 5
        dd = data['RDIM'] / 10.0
        R = np.linspace(0, data['RDIM'], 2) + data['RLEFT']
        Z = np.linspace(0, data['ZDIM'], 2) - data['ZDIM'] / 2.0 + data['ZMID']
        data['RLIM'] = np.array(
            [
                max([R[0], np.min(data['RBBBS']) - dd]),
                min([R[1], np.max(data['RBBBS']) + dd]),
                min([R[1], np.max(data['RBBBS']) + dd]),
                max([R[0], np.min(data['RBBBS']) - dd]),
                max([R[0], np.min(data['RBBBS']) - dd]),
            ]
        )
        data['ZLIM'] = np.array(
            [
                max([Z[0], np.min(data['ZBBBS']) - dd]),
                max([Z[0], np.min(data['ZBBBS']) - dd]),
                min([Z[1], np.max(data['ZBBBS']) + dd]),
                min([Z[1], np.max(data['ZBBBS']) + dd]),
                max([Z[0], np.min(data['ZBBBS']) - dd]),
            ]
        )

    try:
        [data['KVTOR'], data['RVTOR'], data['NMASS']] = list(map(float, [_f for _f in EQDSK[offset : offset + 1][0].split(' ') if _f]))
        offset = offset + 1

        if data['KVTOR'] > 0:
            data['PRESSW'] = np.array(list(map(float, splitter(merge(EQDSK[offset : offset + nlNW])))))
            offset = offset + nlNW
            data['PWPRIM'] = np.array(list(map(float, splitter(merge(EQDSK[offset : offset + nlNW])))))
            offset = offset + nlNW

        if data['NMASS'] > 0:
            data['DMION'] = np.array(list(map(float, splitter(merge(EQDSK[offset : offset + nlNW])))))
            offset = offset + nlNW

        data['RHOVN'] = np.array(list(map(float, splitter(merge(EQDSK[offset : offset + nlNW])))))
        offset = offset + nlNW
    except Exception:
        pass

    # add RHOVN if missing
    if 'RHOVN' not in data or not len(data['RHOVN']) or not np.sum(data['RHOVN']):
        # add RHOVN if QPSI is non-zero (ie. vacuum gEQDSK)
        if np.sum(np.abs(data['QPSI'])):
            phi = integrate.cumtrapz(data['QPSI'], np.linspace(data['SIMAG'], data['SIBRY'], len(data['QPSI'])), initial=0)
            data['RHOVN'] = np.sqrt(np.abs(2 * np.pi * phi / (np.pi * data['BCENTR'])))
            if np.nanmax(data['RHOVN']) > 0:
                data['RHOVN'] = data['RHOVN'] / np.nanmax(data['RHOVN'])
        else:
            # if no QPSI information, then set RHOVN to zeros
            data['RHOVN'] = data['QPSI'] * 0.0

    # fix some gEQDSK files that do not fill PRES info (eg. EAST)
    if not np.sum(data['PRES']):
        pres = integrate.cumtrapz(data['PPRIME'], np.linspace(data['SIMAG'], data['SIBRY'], len(data['PPRIME'])), initial=0)
        data['PRES'] = pres - pres[-1]

    os.chdir(cwd)

    return data
