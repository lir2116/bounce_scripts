#!/usr/bin/env python3

"""
Created Feb 23 2022

@author: rondinil
"""

#from omfit.omfit_tree import *
import numpy as np
import scipy as scipy
import matplotlib.pyplot as plt
from scipy import interpolate