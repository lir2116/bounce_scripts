#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 25 16:28:32 2022

@author: samuelfreiberger
"""

from omfit.omfit_tree import *
import numpy as np
import scipy as scipy
#import matplotlib.pyplot as plt
#import matplotlib.colormaps as cm


def r_z_Bt(r, z, eqdsk):
    #calculates Bt along a flux surface given the set of points r,z that defines
    #the surface
    rz_points=[]
    #interpolates the toroidal magnetic field at each point (r,z) in a given flux surfac
    Bt=scipy.interpolate.interp2d(eqdsk['AuxQuantities']['R'], eqdsk['AuxQuantities']['Z'], eqdsk['AuxQuantities']['Bt'])
    for i in range(len(r)):
        #makes a list of lists of coordinates
        rz_points.append([r[i],z[i]])
    for x in range(len(rz_points)):
        #adds the toroidal field at each point to the list describing the point
        rz_points[x].append(float(Bt(rz_points[x][0],rz_points[x][1])))
    rz_points=np.transpose(np.array(rz_points))
    return rz_points

def ft_curvature(r,z,eqdsk,T,n):
    #sorts particles into good curvature trapped,
    #bad curvature trapped, and circulating based
    #on energy

    #sets the governing constants of the energy distribution in the plasma
    k=1.38e-23
    m=3.43e-27
    sigma=np.sqrt(k*T/m)
    mu=0

    #samples parallel and perpendicular energies from gaussian distributions with given temperature
    v_pars = np.random.normal(mu, sigma, n)
    v_perps = np.random.normal(mu, sigma, n)

    #Pulls the toroidal field info from the r_Z_Bt list created above
    Bt = r_z_Bt(r, z, eqdsk)[2]
    Bt_list = list(Bt)
    Bt_min = -min(abs(Bt))
    Bt_max = -max(abs(Bt))
    Bt_sorted = sorted(Bt_list)
    Bt_sorted.reverse()

    good = []
    bad= []
    passing= []
    #generates the point in the equilibrium designated as the peak
    z_list=list(z)
    r_zmax=r[z_list.index(max(z))]
    #iterates through velocities
    for i in range(len(v_pars)):
        v_par=v_pars[i]
        v_perp=2*v_perps[i] #double weights v_perp to keep thermodynamics happy
        E = (m / 2)*(v_par**2 + v_perp**2)
        for i in range(len(Bt_list)):
            #evaluates trapping condition around the flux surface and adds information to particle info
            if E <= (m/2)*((v_perp**2)/Bt_min)*(Bt_sorted[i]) and r[Bt_list.index(Bt_sorted[i])] < r_zmax:
                good.append([v_par, v_perp, r[Bt_list.index(Bt_sorted[i])],z[Bt_list.index(Bt_sorted[i])]])
                break
            elif E <= (m/2)*((v_perp**2)/Bt_min)*Bt_sorted[i] and r[Bt_list.index(Bt_sorted[i])] >= r_zmax:
                bad.append([v_par, v_perp, r[Bt_list.index(Bt_sorted[i])],z[Bt_list.index(Bt_sorted[i])]])
                break
            elif E >(m/2)*((v_perp**2)/Bt_min)*Bt_sorted[i] and abs(Bt_max) > abs(Bt_sorted[i]):
                continue
            elif E > (m/2)*((v_perp**2)/Bt_min)*Bt_sorted[i] and abs(Bt_max) <= abs(Bt_sorted[i]):
                passing.append([v_par, v_perp, r[Bt_list.index(Bt_sorted[i])],z[Bt_list.index(Bt_sorted[i])]])
    return good, bad, passing


def ft_curve_scan(scan, res, n, _min, _max):
    '''


    Parameters
    ----------
    scan : file path
        folder containing eqdsk files you want to analyze
    res : int
        grid resolution of eqdsks in scan
    n : positive int
        number of particles you want to test on each flux surface
    _min : float
        minimum triangularity
    _max : float
        maximum triangularity

    Returns
    -------
    ft : list
        total trapped particle fraction
    ft_good : list
        good curvature trapped particle fraction

    '''
    #iterates through eqdsks and flux surfaces to calculate total trapped particle fractions
    fig, ax = plt.subplots()

    #iterates through scan
    for item in scan:
        eqdsk = scan[item]
        T=1.2e3
        ft=[]
        ft_good=[]
        surfaces=list(range(0,res))
        #iterates through flux surfaces
        for surface in surfaces:
            #computes r and z coordinates for each flux surface
            r=eqdsk['fluxSurfaces']['flux'][surface]['R']
            z=eqdsk['fluxSurfaces']['flux'][surface]['Z']
            #calclulates trapping info on surface
            good_eqdsk, bad_eqdsk, passing_eqdsk = ft_curvature(r,z,eqdsk,T,n)
            #updates total trapped particle fration and good curvature fraction
            ft_good.append((len(good_eqdsk))/(len(good_eqdsk)+len(bad_eqdsk)))
            ft.append((len(good_eqdsk)+len(bad_eqdsk))/(len(good_eqdsk)+len(bad_eqdsk)+len(passing_eqdsk)))
        #calculates normalized radius
        psi_n=scan['{}'.format(item)]['AuxQuantities']['PSI_NORM']

        #interpolates surface fractions onto normalized radius
        ft_good_new = scipy.interpolate.interp1d(psi_n, ft_good)
        ft_new = scipy.interpolate.interp1d(psi_n, ft)
        '''TODO: make keyword argument that allows the user to choose whether they want total trapped
        particle fraction for each eqdsk in a scan or the good curvature fraction'''
        x_new = np.array(surfaces)/res
        y_new = ft_good_new(x_new)   #set to ft_good_new or ft_new based on whether you want ft_good or ft for the scan
        item=str(item)

        #calculates triangularity of a given eqdsk
        x=eqdsk['fluxSurfaces']['geo']['delta']
        f=scipy.interpolate.interp1d(eqdsk['AuxQuantities']['PSI_NORM'], x)(0.95)
        tri='{:.2f}'.format(f)

        #beginning of plotting
        cmap=cm.get_cmap('plasma')
        c=cmap((float(tri)-(_max))/((_min)-(_max)))

        ax.plot(x_new, y_new, label=tri, c=c)
        #ax.plot(1-eqdsk['fluxSurfaces']['avg']['fc'])
    #more plotting stuff!
    ax.set_xlabel('psi_n')
    ax.set_ylabel('ft')
    plt.legend(title='Triangularity')
    plt.title('Good Curvature Bounce vs. Triangularity @ PSIN=0.95')
    plt.show()
    plt.savefig('/fusion/projects/omfit-results/freibergers/figures/100064_test.pdf')
    return ft, ft_good


#mainish --defines arguments and runs script
scan = OMFIT['g_scans']['100064']
res=65
n=2500
_min=-0.18
_max=0.26
ft_curve_scan(scan, res, n, _min, _max)
